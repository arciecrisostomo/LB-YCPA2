package dataStructures;

public class TreeNode {
    public Object data;
    public TreeNode left;
    public TreeNode right;
}
