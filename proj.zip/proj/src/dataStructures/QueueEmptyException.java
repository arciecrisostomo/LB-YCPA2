package dataStructures;

public class QueueEmptyException extends RuntimeException {
    public QueueEmptyException(String s) {
        super(s);
    }
}