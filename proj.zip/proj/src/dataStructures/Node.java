package dataStructures;

public class Node {
    Object data;
    Node reference;
}
