package dataStructures;


public class QueueFullException extends RuntimeException {
    public QueueFullException(String s) {
        super(s);
    }
}

